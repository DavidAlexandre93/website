<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>BookFace - instalação</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body bgcolor="#0066cc">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr bgcolor="#99ccff">
	<td width="15" nowrap="nowrap">&nbsp;</td>
	<td width="745" height="60" colspan="3" class="logo" nowrap="nowrap"><br />
	BookFace <span class="tagline">| PROGRAMA DE INSTALAÇÃO </span></td>
	<td width="100%">&nbsp;</td>
	</tr>

	<tr bgcolor="#003399">
	<td width="15" nowrap="nowrap">&nbsp;</td>
	<td height="36" colspan="3" id="navigation" nowrap="nowrap" class="navText"><a href="javascript:;">THE FACEBOOK CLONE</a></td>
	<td>&nbsp;</td>
	</tr>

	<tr bgcolor="#ffffff">
	<td width="15" valign="top"><img src="spacer.gif" alt="" width="15" height="1" border="0" /></td>
	<td width="140" valign="top"><img src="spacer.gif" alt="" width="140" height="1" border="0" /></td>
	<td width="505" valign="top"><br />
	<table border="0" cellspacing="0" cellpadding="2" width="440">
		<tr>
<?php
////////////////////
$cam = $_SERVER['QUERY_STRING'];
if($cam==null) {
echo '		<td class="pageName">Bem-vindo</td>
		</tr>

		<tr>
		<td align="left" valign="top" class="bodyText">
		<p>Bem-vindo ao programa de instalação do Bookface. <br />
                   <a href="?config">Clique aqui</a> para continuar.</p>';
}
elseif($cam=="config") {
  echo '                <td class="pageName">Configuração</td>
                </tr>

                <tr>
                <td align="left" valign="top" class="bodyText">
                <p><form action="?finish" method="post">
Digite a senha para a administração da rede:<br>
<input type="password" name="admin_password"><br><br>
Digite novamente a senha para confirmação:<br>
<input type="password" name="r_admin_password"><hr size=1>
<b>MySQL</b><br>
Servidor:<br>
<input type="text" name="mysql_hostname" value="localhost"><br><br>
Usuário:<br>
<input type="text" name="mysql_user"><br><br>
Senha:<br>
<input type="password" name="mysql_password"><br><br>
Banco de dados:<br>
<input type="text" name="mysql_database"><br><br>
<input type="submit" value="Instalar">
</form></p>';
}
elseif($cam=="finish") {
  $config = array();
  $config['admin_password'] = addslashes($_POST['admin_password']);
  $config['mysql_hostname'] = addslashes($_POST['mysql_hostname']);
  $config['mysql_user'] = addslashes($_POST['mysql_user']);
  $config['mysql_password'] = addslashes($_POST['mysql_password']);
  $config['mysql_database'] = addslashes($_POST['mysql_database']);

  if($config['admin_password']!=$_POST['r_admin_password']) {
    die('<script>
alert("Confirme corretamente a senha de administrador.");
history.go(-1);
</script>');
  }
  $cfg_file = '<?php
$admin_password = "'.$config['admin_password'].'"; // senha da área de administração (/admin)
$mysql_hostname = "'.$config['mysql_hostname'].'"; // servidor MySQL
$mysql_user = "'.$config['mysql_user'].'"; // usuário MySQL
$mysql_password = "'.$config['mysql_password'].'"; // senha MySQL
$mysql_database = "'.$config['mysql_database'].'"; // banco de dados MySQL
$prefix = ""; // prefixo das tabelas (desnecessário)

// não configure aqui
$installed = true; //
$env = $_SERVER[\'QUERY_STRING\'];
$naofaz = Array("order", "concat", "union", "ORDER", "CONCAT", "UNION", "select", "SELECT", "drop", "DROP");
$env = str_replace($naofaz, "%SQLI", $env);
if(strpos($env, "%SQLI")!=false OR @mysql_error()!=null) {
  die(\'<script> location.href="about:blank"; </script>\');
}

$bd = mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect database");
mysql_select_db($mysql_database, $bd) or die("Could not select database");

$con = mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect database");
mysql_select_db($mysql_database, $con) or die("Could not select database");

$conn = mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect database");
mysql_select_db($mysql_database, $conn) or die("Could not select database");

$link = mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect database");
mysql_select_db($mysql_database, $link) or die("Could not select database");

$db = mysql_select_db($mysql_database) or die("Could not select database");

if($installed==false) {
  die("<script> location.href=\'install/\'; </script>");
}

if(is_dir("install") AND $installed==true) {
  die("Exclua o diretório \"install\" para continuar.");
}
if(!is_writable("uploadedimage")) {
  die("Falta CHMOD 777 em \"uploadedimage\"");
}
?>';
if(is_writable("../config.php")) {
  $abre = fopen("../config.php", "w");
  fwrite($abre, $cfg_file);
  fclose($abre);
  echo '                <td class="pageName">Pronto!</td>
                </tr>

                <tr>
                <td align="left" valign="top" class="bodyText">
                <p>Sua rede social já está funcionando.<br>
No entanto, você deve excluir o diretório "install".</p>';
}

  echo '                <td class="pageName">Quase pronto!</td>
                </tr>

                <tr>
                <td align="left" valign="top" class="bodyText">
                <p>Falta apenas um passo.<br>
Ocorre que não foi possível configurar a rede. Então, abra o arquivo "config.php", remova todo o conteúdo e coloque o seguinte:
<textarea rows=15 cols=75 readonly=readonly onclick=this.select()>'.$cfg_file.'</textarea><br>
Depois disso, exclua o diretório "install" e pronto!</p>';
}
///////////////////
?>

		<br /></td>
		</tr>
	</table>
	&nbsp;<br />
	&nbsp;<br />	</td>
	<td valign="top">&nbsp;</td>
	<td width="100%">&nbsp;</td>
	</tr>

	<tr>
	<td width="15">&nbsp;</td>
    <td width="140">&nbsp;</td>
    <td width="505">&nbsp;</td>
    <td width="100">&nbsp;</td>
    <td width="100%">&nbsp;</td>
  </tr>
</table>
</body>
</html>
