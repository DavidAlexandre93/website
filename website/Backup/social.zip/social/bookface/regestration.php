<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="format1.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
body {
	background-image: url(img/bg2.jpg);
	background-repeat:repeat-x;
	background-color:#d1d7e7;

}
-->
</style></head>

<body>
<div class="mainr">
  <div class="topleft"><img src="img/logo1.jpg" width="175" height="41" /></div>
  
  <div class="qwerty">
  
		<div class="label">
		  <div class="email">Email</div>
		  <div class="password">Password</div>
		</div>
		<div class="label1">
				
				<div class="emailtext"><input name="email" type="text" /></div>
		  		<div class="passwordtext"><input name="password" type="text" />&nbsp;<input name="login" type="button" value="log-in" class="greenButton" /></div>
				
		</div>
		<div class="label2">
		
				<div class="email">
				<div class="radio"><input name="check" type="checkbox" value="" /></div>
				<div class="text1">Keep me Log-in</div>
				</div>
		  		<div class="password">Forgot Password?</div>
		
		</div>
</div>






</div>


<div class="downleft">

  <div class="picture"><img src="img/wala.jpg" width="471" height="257" /></div>
  <div class="field">
  
    <div class="signup">Sign Up</div>
	<div class="free">It's free, and always will be</div>
	<div class="text">
	<form action="register-exec.php" method="post">
	  	<div class="textleft">FirstName:</div>
		<div class="textright"><input name="fname" type="text" class="textfield" /></div>
		<div class="textleft">LastName:</div>
		<div class="textright"><input name="lname" class="textfield" type="text" /></div>
		<div class="textleft">UserName:</div>
		<div class="textright"><input name="login" class="textfield" type="text" /></div>
		<div class="textleft">Password:</div>
		<div class="textright"><input name="password" class="textfield" type="password" /></div>
		<div class="textleft">Cofirm Password:</div>
		<div class="textright"><input name="cpassword" class="textfield" type="password" /></div>
		<div class="textleft">Address:</div>
		<div class="textright"><input name="address" class="textfield" type="text" /></div>
		<div class="textleft">Contact Number:</div>
		<div class="textright"><input name="cnumber" class="textfield" type="text" /><input name="propic" id="dadded" type="hidden" value="uploadedimage/defoult.jpg" /></div>
		<div class="textleft">Email:</div>
		<div class="textright"><input name="email" class="textfield" type="text" /></div>
		<div class="textleft">I am:</div>
		<div class="textright">
			<div class="input-container">
    		<select name="gender" id="gender">
    		<option >Select Sex:</option>
   	 		<option >Female</option>
    		<option >Male</option>
    		</select>
    		</div>
		
		</div>
		<div class="textleft">Birth Day:</div>
		<div class="textright">
		
		<div class="input-container">
    <select name="month">
        <option>Month:</option>
        <option>Jan</option>
        <option>Feb</option>
        <option>Mar</option>
        <option>apr</option>
        <option>Jun</option>
        <option>Jul</option>
        <option>Aug</option>
        <option>Sep</option>
        <option>Oct</option>
        <option>Nov</option>
        <option>Dec</option>
        </select>
    <select name="day">
        <option>Day:</option>
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
        <option>6</option>
        <option>7</option>
        <option>8</option>
        <option>9</option>
        <option>10</option>
        <option>11</option>
        <option>12</option>
        <option>13</option>
        <option>14</option>
        <option>15</option>
        <option>16</option>
        <option>17</option>
        <option>18</option>
        <option>19</option>
        <option>20</option>
        <option>21</option>
        <option>22</option>
        <option>23</option>
        <option>24</option>
        <option>25</option>
        <option>26</option>
        <option>27</option>
        <option>28</option>
        <option>29</option>
        <option>30</option>
        <option>31</option>
      </select>
	<select name="year">
        <option>Year:</option>
        <option>2011</option>
        <option>2010</option>
        <option>2009</option>
        <option>2008</option>
        <option>2007</option>
        <option>2006</option>
        <option>2005</option>
        <option>2004</option>
        <option>2003</option>
        <option>2002</option>
        <option>2001</option>
        <option>2000</option>
        <option>1999</option>
        <option>1998</option>
        <option>1997</option>
        <option>1996</option>
        <option>1995</option>
        <option>1994</option>
        <option>1993</option>
        <option>1992</option>
        <option>1991</option>
        <option>1990</option>
        <option>1989</option>
        <option>1988</option>
		<option>1987</option>
        <option>1986</option>
        <option>1985</option>
        <option>1984</option>
      </select>
    </div>
		
		
		</div>
		<div class="textleft"></div>
		<div class="textright">
		  <br /><label>
		  <input type="submit" name="Submit" value="Sign Up" class="greenButton1" />
		  </label>
		</div>
	</form>	
	</div>
  </div>
</div>
</body>
</html>
