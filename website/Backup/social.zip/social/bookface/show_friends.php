
<div class="top_area">Friends of 99 Points</div>
 
 
<div id="search_area"></div>
 
 
<div style="overflow-y: scroll; height: 370px; margin-top: 3px;">
 
 
<div class="friends_area">
	   <img style="float: left;" src="images/&lt;?php  echo $row['f_image'];?&gt;" alt="" height="50" />
		   <label class="name" style="float: left;">
		   <strong> </strong>
 
		   </label></div>
 
 
 
</div>
