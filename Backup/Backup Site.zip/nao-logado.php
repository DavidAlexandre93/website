<?php

echo"<script language='javascript' type='text/javascript'>alert('Favor se nao tiver cadastro realizar ou realizar o login para acesso');window.location.href='tela-login-cadastro.php'</script>";

?>