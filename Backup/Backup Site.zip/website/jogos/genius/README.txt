A Pen created at CodePen.io. You can find this one at https://codepen.io/Moroshan/pen/bgjqgQ.

 simon game 80's