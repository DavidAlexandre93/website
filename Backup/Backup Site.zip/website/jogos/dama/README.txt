A Pen created at CodePen.io. You can find this one at https://codepen.io/Davidalexandre93/pen/moLXzg.

 A neat game of checkers