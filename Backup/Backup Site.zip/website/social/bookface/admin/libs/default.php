<?php
tpl("Bem-vindo", "Bem-vindo à administração. <br>Utilize o menu ao lado para navegar.", "boasvindas");
?>